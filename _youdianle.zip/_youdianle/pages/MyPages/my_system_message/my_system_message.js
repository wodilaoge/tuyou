const app = getApp()
var util = require("../../../utils/util.js");
Page({
  data: {
    messages: [{
        'time': '2020年5月1日22:28:03',
        'message': '对哇害护卫队会'
      },
      {
        'time': '2020年5月1日22:29:05',
        'message': '阿萨德哈撒U盾哈'
      }
    ]
  },

  onLoad: function(options) {

  },
})