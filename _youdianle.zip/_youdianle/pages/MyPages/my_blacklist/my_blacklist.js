
Page({
  data: {
    fans: [
      {
        'image': '/img/login/icon.png',
        'name': '李曼曼'
      },
      {
        'image': '/img/login/icon.png',
        'name': '李曼曼'
      },
      {
        'image': '/img/login/icon.png',
        'name': '李曼曼'
      },
      {
        'image': '/img/login/icon.png',
        'name': '李曼曼'
      },
      {
        'image': '/img/login/icon.png',
        'name': '李曼曼'
      },
    ]
  },

  onLoad: function (options) {

  },
})